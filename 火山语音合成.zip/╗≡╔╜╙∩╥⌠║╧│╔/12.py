import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
import requests
import uuid
import base64
import threading
from datetime import datetime

# 文字转语音合成函数
def synthesis(text, appid, cluster, voice_type, speed, token):
    url = "https://openspeech.bytedance.com/api/v1/tts"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer;{token}"
    }
    body = {
        "app": {"appid": appid, "cluster": cluster},
        "user": {"uid": "default_uid"},
        "audio": {
            "voice_type": voice_type,
            "encoding": "mp3",
            "speed_ratio": speed,
            "volume_ratio": 1.0,
            "pitch_ratio": 1.0
        },
        "request": {
            "reqid": str(uuid.uuid4()),
            "text": text,
            "operation": "query"
        }
    }
    response = requests.post(url, json=body, headers=headers)
    response_data = response.json()
    if response.status_code == 200 and response_data.get("code") == 3000:
        audio_data = base64.b64decode(response_data["data"])
        return audio_data
    else:
        raise Exception(f"合成失败: {response_data.get('message', '未知错误')}")

# GUI的转换函数
def convert_to_speech():
    text = text_input.get("1.0", tk.END).strip()
    if not text:
        messagebox.showwarning("警告", "请输入要转换的文本！")
        return

    selected_voice = voice_type_combobox.get()
    voice_info = voice_mapping[selected_voice]
    voice_type = voice_info["voice_type"]

    try:
        audio_data = synthesis(text, appid_entry.get(), cluster_entry.get(), voice_type, speed_var.get(), token_entry.get())
        default_filename = datetime.now().strftime("%Y-%m-%d_%H-%M-%S.mp3")
        save_path = filedialog.asksaveasfilename(initialfile=default_filename, defaultextension=".mp3", filetypes=[("MP3文件", "*.mp3")])
        if save_path:
            with open(save_path, 'wb') as f:
                f.write(audio_data)
            messagebox.showinfo("成功", "音频已成功保存！")
    except Exception as e:
        messagebox.showerror("错误", str(e))

# 使用线程显示启动信息提示
def show_startup_message_threaded():
    messagebox.showinfo("信息提示", "xwean.com")

# 启动信息提示线程
def start_startup_message_thread():
    startup_thread = threading.Thread(target=show_startup_message_threaded)
    startup_thread.start()

# 实时更新朗读速度显示，并保留两位小数
def update_speed_label(event=None):
    speed_label.config(text=f"{speed_scale.get():.2f}")

root = tk.Tk()
root.title("文本转语音")

voice_mapping = {
    "通用女声-通用场景-中文": {"voice_type": "BV001_streaming", "场景": "通用场景", "语种": "中文"},
    "通用男声-通用场景-中文": {"voice_type": "BV002_streaming", "场景": "通用场景", "语种": "中文"},
    "日语男声-多语种-日语": {"voice_type": "BV524_streaming", "场景": "多语种", "语种": "日语"},
    "甜宠少御-有声阅读-中文": {"voice_type": "BV113_streaming", "场景": "有声阅读", "语种": "中文"},
    "古风少御-有声阅读-中文": {"voice_type": "BV115_streaming", "场景": "有声阅读", "语种": "中文"},
    "炀炀-通用场景-中文": {"voice_type": "BV705_streaming", "场景": "通用场景", "语种": "中文"},
    "重庆小伙-方言-重庆话": {"voice_type": "BV019_streaming", "场景": "方言", "语种": "重庆话"},
    "广西表哥-方言-广西普通话": {"voice_type": "BV213_streaming", "场景": "方言", "语种": "广西普通话"},
    "气质女生-多语种-日语": {"voice_type": "BV522_streaming", "场景": "多语种", "语种": "日语"},
    "通用赘婿-有声阅读-中文": {"voice_type": "BV119_streaming", "场景": "有声阅读", "语种": "中文"},
    "擎苍-有声阅读-中文": {"voice_type": "BV701_streaming", "场景": "有声阅读", "语种": "中文"},
    "活力男声-Jackson-美式发音-英语": {"voice_type": "BV504_streaming", "场景": "美式发音", "语种": "英语"},
    "灿灿-通用场景-中文": {"voice_type": "BV700_streaming", "场景": "通用场景", "语种": "中文"},
    "活力女声-Ariana-美式发音-英语": {"voice_type": "BV503_streaming", "场景": "美式发音", "语种": "英语"},
    "儒雅青年-有声阅读-中文": {"voice_type": "BV102_streaming", "场景": "有声阅读", "语种": "中文"},
    "知性姐姐-双语-教育场景-中文": {"voice_type": "BV034_streaming", "场景": "教育场景", "语种": "中文"},
    "温柔小哥-教育场景-中文": {"voice_type": "BV033_streaming", "场景": "教育场景", "语种": "中文"},
    "活泼女声-视频配音-中文": {"voice_type": "BV005_streaming", "场景": "视频配音", "语种": "中文"},
    "奶气萌娃-特色音色-中文": {"voice_type": "BV051_streaming", "场景": "特色音色", "语种": "中文"},
    "亲切女声-客服场景-中文": {"voice_type": "BV007_streaming", "场景": "客服场景", "语种": "中文"},
    "阳光男声-视频配音-中文": {"voice_type": "BV056_streaming", "场景": "视频配音", "语种": "中文"},
    "东北老铁-方言-东北话": {"voice_type": "BV021_streaming", "场景": "方言", "语种": "东北话"}
}


# 界面布局
ttk.Label(root, text="AppID：").grid(column=0, row=0, sticky=tk.W)
appid_entry = ttk.Entry(root)
appid_entry.grid(column=1, row=0, sticky=tk.EW)

ttk.Label(root, text="Cluster：").grid(column=0, row=1, sticky=tk.W)
cluster_entry = ttk.Entry(root)
cluster_entry.grid(column=1, row=1, sticky=tk.EW)

ttk.Label(root, text="Access Token：").grid(column=0, row=2, sticky=tk.W)
token_entry = ttk.Entry(root)
token_entry.grid(column=1, row=2, sticky=tk.EW)

ttk.Label(root, text="音色选择：").grid(column=0, row=3, sticky=tk.W)
voice_type_combobox = ttk.Combobox(root, values=list(voice_mapping.keys()))
voice_type_combobox.grid(column=1, row=3, sticky=tk.EW)
voice_type_combobox.current(0)

ttk.Label(root, text="朗读速度：").grid(column=0, row=4, sticky=tk.W)
speed_var = tk.DoubleVar(value=1.0)
speed_scale = ttk.Scale(root, from_=0.2, to=3, variable=speed_var, orient=tk.HORIZONTAL, command=update_speed_label)
speed_scale.grid(column=1, row=4, sticky=tk.EW)
speed_label = ttk.Label(root, text="1.00")
speed_label.grid(column=2, row=4, sticky=tk.W)

ttk.Label(root, text="文本内容：").grid(column=0, row=5, sticky=tk.NW)
text_input = scrolledtext.ScrolledText(root, height=10)
text_input.grid(column=0, row=6, columnspan=3, sticky=tk.EW)

convert_button = ttk.Button(root, text="转换为语音", command=convert_to_speech)
convert_button.grid(column=0, row=7, columnspan=3, sticky=tk.EW)

root.after(100, start_startup_message_thread)

root.mainloop()
